<div class="sidebar col-lg-3">
	<?php
$lang = get_bloginfo('language'); 
if( $lang == "zh-TW" ) {
	if (is_active_sidebar('sidebar-4') && is_single()) {
	    dynamic_sidebar('sidebar-4');
	} elseif(is_active_sidebar('sidebar-5') && is_page()){
		dynamic_sidebar('sidebar-5');
	} else {
		dynamic_sidebar('sidebar-6');
	}
} elseif( $lang == "en-US" ) {
	if (is_active_sidebar('sidebar-7') && is_single()) {
	    dynamic_sidebar('sidebar-7');
	} elseif(is_active_sidebar('sidebar-8') && is_page()){
		dynamic_sidebar('sidebar-8');
	} else {
		dynamic_sidebar('sidebar-9');
	}
} else{	
	if (is_active_sidebar('sidebar-1') && is_single()) {
	    dynamic_sidebar('sidebar-1');
	} elseif(is_active_sidebar('sidebar-2') && is_page()){
		dynamic_sidebar('sidebar-2');
	} else {
		dynamic_sidebar('sidebar-3');
	}
}
	?>

    <div class="news-info">
        <ul>
            <?php
            $querys = new WP_Query(array('posts_per_page' => 3, 'category_name' => $video));
            if ( $querys->have_posts() ) : while ($querys->have_posts()) : $querys->the_post(); ?>
                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
            <?php endwhile; endif; wp_reset_query();?>
        </ul>
        <a class="more" href="<?php echo $cat_links; ?>">更多视频</a>
    </div>


</div>