$(document).ready(function(){
	$('.lang').click(function(){
		$('.lang-box').slideToggle();
	});
	$('.mobile-menu').click(function(){
		$('.menu').slideToggle();
	});
});